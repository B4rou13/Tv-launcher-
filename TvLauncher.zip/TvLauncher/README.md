# TV Launcher

A simple, clean home screen for Android TV, built with Kotlin and Jetpack Compose.

## Features

- **My apps row** on the home screen: only the apps you pick, placed lower on the screen. Apps are wide 16:9 tiles that use the app's own TV banner; apps without one show their icon on a tile in the icon's colour. The selected tile zooms in and shows its name.
- **Open animation**: when you open an app, the home screen dims softly, its tile grows from where it sits and its corners straighten, the banner melts into the app's colour and the icon settles in the middle like a splash screen, then the app starts.
- **Choosing home apps**: open **Apps** (bottom bar or the "All apps" tile), press **Edit home apps**, select apps to add or remove them, then press **Done**. Apps appear in the order you pick them.
- **All apps** grid: every installed app, including sideloaded apps that have no TV banner. Select an app to open it.
- **Clock and date** in the top left, following the TV's 12 / 24 hour setting and language.
- **Centered layout**: the app rows sit in the middle of the screen, under the clock.
- **Hide apps**: open **Apps**, press **Hide apps**, select the apps you do not want, then **Done**. Hidden apps disappear from the home screen, the All apps grid and Continue watching. Open **Hide apps** again to show them again.
- **Continue watching** row: the same list your TV's own home screen shows ("Ma sélection"). Wide posters with a bar for how much you watched, newest first; the title shows under the selected card, and selecting one resumes it in its app (Stremio, Nuvio, CloudStream, YouTube...). It needs a one-time permission: the launcher asks Android for it with a normal Allow / Don't allow question on first start (or when you select **Turn on Continue watching**). Only if your TV never shows the question does a help card appear with an adb command to copy.
- **Make default**: a button in the top right (shown only while the launcher is not the default home app). It asks Android to make TV Launcher the home app. If your TV has no screen for that, a help card explains the other ways, including the adb command, with a button that copies it.
- **Smooth backgrounds**: choosing a wallpaper fades it in over the old one, and the picker tiles ease in and out without bouncing or being cut off at the top.
- **Top right buttons**: Apps, Settings (opens the Android system settings) and Background (pick one of three built-in wallpapers (Pixel sky, Cat parade, Misty peaks) or add your own image from TV storage or a USB drive).
- Every button, icon and card zooms in when selected.
- Works with the remote: D-pad to move, OK to open, Back to return.

## Build

You need Android Studio (Koala or newer) or JDK 17 plus the Android SDK.

**Android Studio:** open this folder, let Gradle sync, then run the `app` configuration on your TV or an Android TV emulator.

**Command line:**

```bash
gradle wrapper        # one time, creates ./gradlew
./gradlew assembleDebug
```

The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

**GitHub:** the workflow in `.github/workflows/build.yml` builds the APK on every push. Download it from the run's *Artifacts*.

## Install on the TV

```bash
adb connect <tv-ip-address>
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Then press the Home button on the remote and choose **TV Launcher** as the default home app.
If your TV does not offer the choice, this command may work:

```bash
adb shell cmd package set-home-activity com.example.tvlauncher/.MainActivity
```

## Notes

- **Watch next** needs a permission that some TVs only grant to system apps. The launcher asks for it on first start. If the TV refuses, the row shows a "Turn on Continue watching" card that explains how to grant it, and everything else works.
- **Add your own image** uses Android's file picker. If your TV has none, install a file manager that provides one.
- To rename the app, change `applicationId` and `namespace` in `app/build.gradle.kts` and move the Kotlin package folder to match.

## Project layout

```
app/src/main/java/com/example/tvlauncher/
  MainActivity.kt          entry point, permissions, file picker
  LauncherViewModel.kt     screen state, apps, wallpaper
  data/                    installed apps, Watch Next, wallpapers
  ui/                      home, apps grid and wallpaper screens
app/src/main/res/drawable/        icons
app/src/main/res/drawable-nodpi/ the built-in wallpapers (wp_*.jpg and small wp_*_thumb.jpg)
```

## License

MIT, see `LICENSE`.

## Continue watching needs a permission

The launcher reads the Watch Next list, which Android protects with the permission
`READ_TV_LISTINGS`. If the row shows "Turn on Continue watching", select it. If your TV shows no
dialog, run this once on a computer connected to the TV, then reopen the launcher:

```bash
adb shell pm grant com.example.tvlauncher android.permission.READ_TV_LISTINGS
```
