package com.example.tvlauncher

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.app.role.RoleManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.graphics.Color
import android.view.KeyEvent
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.tvlauncher.data.WatchNextRepository
import com.example.tvlauncher.ui.LauncherApp
import com.example.tvlauncher.ui.LauncherTheme

class MainActivity : ComponentActivity() {

    private val viewModel: LauncherViewModel by viewModels()

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                viewModel.importWallpaper(uri) { ok ->
                    if (!ok) toast("That file could not be used as a wallpaper.")
                }
            }
        }

    /** True only when the person pressed the "Turn on Continue watching" card. */
    private var explainIfDenied = false

    private val requestEpgPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            viewModel.refreshWatchNext()
            if (!granted && explainIfDenied) viewModel.setWatchNextHelp(true)
            explainIfDenied = false
        }

    /** When the "make default" question was shown, to notice a screen that closes at once. */
    private var roleRequestedAt = 0L

    private val requestHomeRole =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            viewModel.refreshDefaultHome()
            val closedAtOnce = SystemClock.elapsedRealtime() - roleRequestedAt < 700
            if (!viewModel.isDefaultHome && closedAtOnce) openHomeSettingsOrHelp()
        }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val crash = CrashLog.read(this)
        if (crash != null) {
            showCrash(crash)
            return
        }

        if (!WatchNextRepository.hasPermission(this) && !viewModel.epgPermissionAsked) {
            viewModel.epgPermissionAsked = true
            try {
                requestEpgPermission.launch(WatchNextRepository.PERMISSION)
            } catch (e: Exception) {
                // Some TVs have no permission dialog; the Watch Next row just stays hidden.
            }
        }

        setContent {
            LauncherTheme {
                LauncherApp(
                    viewModel = viewModel,
                    onLaunch = ::startApp,
                    onOpenSettings = ::openSettings,
                    onPickImage = ::pickWallpaperImage,
                    onRequestWatchNext = ::askWatchNextPermission,
                    onMakeDefault = ::makeDefault,
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (crashShown) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        try {
            registerReceiver(packageReceiver, filter)
            receiverRegistered = true
        } catch (e: Exception) {
            receiverRegistered = false
        }
    }

    override fun onStop() {
        if (receiverRegistered) {
            try {
                unregisterReceiver(packageReceiver)
            } catch (e: Exception) {
                // Already gone.
            }
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        if (crashShown) return
        Sounds.mute(800)
        // Back from an app: remove the open-app animation that was covering the screen.
        viewModel.clearLaunch()
        viewModel.refreshWatchNext()
        viewModel.refreshDefaultHome()
    }

    /** Pressing the Home button while the launcher is open brings back the home screen. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        viewModel.goHome()
    }

    private var crashShown = false
    private var receiverRegistered = false

    /** Shows the error of the last crash, so it can be read and sent for fixing. */
    private fun showCrash(text: String) {
        crashShown = true
        val view = TextView(this).apply {
            this.text = "The launcher crashed last time. Please send a photo of this screen.\n" +
                "(Press OK or Back to try again.)\n\n" + text
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(48, 32, 48, 32)
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFocusable = true
            addView(view)
        }
        setContentView(scroll)
        scroll.requestFocus()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (crashShown && (keyCode == KeyEvent.KEYCODE_BACK ||
                keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
                keyCode == KeyEvent.KEYCODE_ENTER)
        ) {
            CrashLog.clear(this)
            recreate()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun startApp(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            viewModel.clearLaunch()
            toast("This app could not be opened.")
        }
    }

    private fun openSettings() {
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("The system settings could not be opened.")
        }
    }

    private fun askWatchNextPermission() {
        explainIfDenied = true
        try {
            requestEpgPermission.launch(WatchNextRepository.PERMISSION)
        } catch (e: Exception) {
            explainIfDenied = false
            viewModel.setWatchNextHelp(true)
        }
    }

    /**
     * Asks Android to make this launcher the home app. Android 10 and newer have a system
     * question for it. If it is missing or closes at once, the home-app settings page is tried,
     * and as a last step the help screen explains how to do it by hand.
     */
    private fun makeDefault() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roles = getSystemService(RoleManager::class.java)
            if (roles != null &&
                roles.isRoleAvailable(RoleManager.ROLE_HOME) &&
                !roles.isRoleHeld(RoleManager.ROLE_HOME)
            ) {
                try {
                    roleRequestedAt = SystemClock.elapsedRealtime()
                    requestHomeRole.launch(roles.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    return
                } catch (e: Exception) {
                    // No screen for it on this TV: try the next way.
                }
            }
        }
        openHomeSettingsOrHelp()
    }

    private fun openHomeSettingsOrHelp() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            viewModel.setDefaultHelp(true)
        }
    }

    private fun pickWallpaperImage() {
        try {
            pickImage.launch(arrayOf("image/*"))
        } catch (e: ActivityNotFoundException) {
            toast("No file picker found on this TV. Install a file manager that supports it.")
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
