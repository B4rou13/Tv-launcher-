package com.example.tvlauncher

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tvlauncher.data.AppEntry
import com.example.tvlauncher.data.AppRepository
import com.example.tvlauncher.data.DefaultHome
import com.example.tvlauncher.data.FavoritesStore
import com.example.tvlauncher.data.PackageListStore
import com.example.tvlauncher.data.WallpaperStore
import com.example.tvlauncher.data.Wallpapers
import com.example.tvlauncher.data.WatchNextItem
import com.example.tvlauncher.data.WatchNextRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen { Home, Apps, Wallpaper }

/** An app that is being opened, and where its tile was on screen. */
data class LaunchRequest(val app: AppEntry, val bounds: Rect)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val wallpaperStore = WallpaperStore(context)
    private val favoritesStore = FavoritesStore(context)
    private val hiddenStore = PackageListStore(context, "hidden")

    var screen by mutableStateOf(Screen.Home)
        private set

    var apps by mutableStateOf<List<AppEntry>>(emptyList())
        private set

    var watchNext by mutableStateOf<List<WatchNextItem>>(emptyList())
        private set

    /** False when the TV has not given this launcher access to the Watch next list. */
    var watchNextAllowed by mutableStateOf(WatchNextRepository.hasPermission(context))
        private set

    /** Set while the open-app animation runs and the app starts. */
    var launching by mutableStateOf<LaunchRequest?>(null)
        private set

    /** Package names of the apps picked for the home screen, in the order they were picked. */
    var favorites by mutableStateOf(favoritesStore.load())
        private set

    /** Package names of the apps the user hid. They show up nowhere except in "Hide apps". */
    var hidden by mutableStateOf(hiddenStore.load())
        private set

    /** Every installed app that is not hidden. */
    val visibleApps: List<AppEntry>
        get() = apps.filter { it.packageName !in hidden }

    /** The picked apps that are still installed and not hidden, in the picked order. */
    val homeApps: List<AppEntry>
        get() = favorites.mapNotNull { pkg -> visibleApps.firstOrNull { it.packageName == pkg } }

    var wallpaperId by mutableStateOf(wallpaperStore.selectedId)
        private set

    var customWallpaper by mutableStateOf<ImageBitmap?>(null)
        private set

    /** Makes sure the Watch Next permission is only requested once per run. */
    var epgPermissionAsked = false

    /** True when the Home button on the remote opens this launcher. */
    var isDefaultHome by mutableStateOf(DefaultHome.isDefault(context))
        private set

    /** True while the "how to make this the home app" help is on screen. */
    var showDefaultHelp by mutableStateOf(false)
        private set

    /** True while the "how to turn on Continue watching" help is on screen. */
    var showWatchNextHelp by mutableStateOf(false)
        private set

    init {
        refreshApps()
        loadCustomWallpaper()
    }

    fun show(target: Screen) {
        screen = target
    }

    fun startLaunch(app: AppEntry, bounds: Rect) {
        if (launching == null) launching = LaunchRequest(app, bounds)
    }

    fun clearLaunch() {
        launching = null
    }

    fun goHome() {
        screen = Screen.Home
    }

    fun refreshDefaultHome() {
        isDefaultHome = DefaultHome.isDefault(context)
    }

    fun setDefaultHelp(show: Boolean) {
        showDefaultHelp = show
    }

    fun setWatchNextHelp(show: Boolean) {
        showWatchNextHelp = show
    }

    fun refreshApps() {
        viewModelScope.launch {
            apps = withContext(Dispatchers.Default) { AppRepository.load(context) }
        }
    }

    fun refreshWatchNext() {
        watchNextAllowed = WatchNextRepository.hasPermission(context)
        viewModelScope.launch {
            watchNext = withContext(Dispatchers.IO) { WatchNextRepository.load(context) }
        }
    }

    /** Adds the app to the home screen, or removes it if it is already there. */
    fun toggleFavorite(packageName: String) {
        favorites = if (packageName in favorites) favorites - packageName else favorites + packageName
        favoritesStore.save(favorites)
    }

    /** Hides the app everywhere, or shows it again if it is already hidden. */
    fun toggleHidden(packageName: String) {
        hidden = if (packageName in hidden) hidden - packageName else hidden + packageName
        hiddenStore.save(hidden)
    }

    fun selectWallpaper(id: String) {
        wallpaperId = id
        wallpaperStore.selectedId = id
    }

    private fun loadCustomWallpaper() {
        viewModelScope.launch {
            customWallpaper = withContext(Dispatchers.IO) { wallpaperStore.loadCustom() }
            if (wallpaperId == Wallpapers.CUSTOM_ID && customWallpaper == null) {
                selectWallpaper(Wallpapers.builtIn.first().id)
            }
        }
    }

    /** Copies the chosen image and uses it as wallpaper. [onResult] tells whether it worked. */
    fun importWallpaper(uri: Uri, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val bitmap = withContext(Dispatchers.IO) {
                if (wallpaperStore.saveCustom(uri)) wallpaperStore.loadCustom() else null
            }
            if (bitmap != null) {
                customWallpaper = bitmap
                selectWallpaper(Wallpapers.CUSTOM_ID)
            }
            onResult(bitmap != null)
        }
    }
}
