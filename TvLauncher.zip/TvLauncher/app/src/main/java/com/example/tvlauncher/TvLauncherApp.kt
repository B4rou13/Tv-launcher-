package com.example.tvlauncher

import android.app.Application

class TvLauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
    }
}
