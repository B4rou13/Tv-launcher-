package com.example.tvlauncher

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock

/**
 * The launcher's own small sounds: a soft tick when the selection moves, a pop when something
 * is chosen and a gentle sweep when an app opens. They play even when the TV's own system
 * sounds are off, and can be switched off in "Size & sound".
 */
object Sounds {
    private var pool: SoundPool? = null
    private var tickId = 0
    private var selectId = 0
    private var openId = 0
    private var mutedUntil = 0L
    private var lastTick = 0L

    var enabled = true
        private set

    fun init(context: Context) {
        if (pool != null) return
        try {
            val app = context.applicationContext
            enabled = app.getSharedPreferences("launcher", Context.MODE_PRIVATE)
                .getBoolean("sounds", true)
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val sp = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attributes).build()
            tickId = sp.load(app, R.raw.tick, 1)
            selectId = sp.load(app, R.raw.select, 1)
            openId = sp.load(app, R.raw.open, 1)
            pool = sp
        } catch (e: Exception) {
            pool = null
        }
    }

    fun setEnabled(context: Context, on: Boolean) {
        enabled = on
        try {
            context.applicationContext.getSharedPreferences("launcher", Context.MODE_PRIVATE)
                .edit().putBoolean("sounds", on).apply()
        } catch (e: Exception) {
            // The choice just is not remembered.
        }
        if (on) select()
    }

    /** Keeps the sounds quiet for a moment, for example while a screen puts focus on its first item. */
    fun mute(millis: Long) {
        mutedUntil = SystemClock.uptimeMillis() + millis
    }

    fun tick() {
        val now = SystemClock.uptimeMillis()
        if (now - lastTick < 45) return
        lastTick = now
        play(tickId, 0.45f)
    }

    fun select() = play(selectId, 0.7f)

    fun open() = play(openId, 0.6f)

    private fun play(id: Int, volume: Float) {
        if (!enabled || id == 0) return
        if (SystemClock.uptimeMillis() < mutedUntil) return
        try {
            pool?.play(id, volume, volume, 1, 0, 1f)
        } catch (e: Exception) {
            // Never let a sound break the launcher.
        }
    }
}
