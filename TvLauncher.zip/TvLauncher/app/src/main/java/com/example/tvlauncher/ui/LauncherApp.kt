package com.example.tvlauncher.ui

import android.content.Intent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.tvlauncher.LauncherViewModel
import com.example.tvlauncher.Screen
import com.example.tvlauncher.Sounds
import com.example.tvlauncher.data.Wallpapers

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(), content = content)
}

@Composable
fun LauncherApp(
    viewModel: LauncherViewModel,
    onLaunch: (Intent) -> Unit,
    onOpenSettings: () -> Unit,
    onPickImage: () -> Unit,
    onRequestWatchNext: () -> Unit,
    onMakeDefault: () -> Unit,
) {
    // Keep quiet while a new screen puts the selection on its first item.
    LaunchedEffect(viewModel.screen) { Sounds.mute(700) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        LauncherBackground(
            wallpaperId = viewModel.wallpaperId,
            custom = viewModel.customWallpaper,
            extraDim = viewModel.screen != Screen.Home,
        )

        if (viewModel.showDefaultHelp) {
            DefaultHelpScreen(onClose = { viewModel.setDefaultHelp(false) })
        } else if (viewModel.showWatchNextHelp) {
            WatchNextHelpScreen(onClose = { viewModel.setWatchNextHelp(false) })
        } else when (viewModel.screen) {
            Screen.Home -> HomeScreen(
                apps = viewModel.homeApps,
                watchNext = viewModel.shownWatchNext,
                watchFiltered = viewModel.watchSources.isNotEmpty(),
                appsSize = viewModel.appsSize,
                watchSize = viewModel.watchSize,
                onOpenSizes = { viewModel.show(Screen.Sizes) },
                onChooseWatchApps = { viewModel.show(Screen.WatchSources) },
                watchNextAllowed = viewModel.watchNextAllowed,
                isDefaultHome = viewModel.isDefaultHome,
                onMakeDefault = onMakeDefault,
                onLaunch = onLaunch,
                onLaunchApp = viewModel::startLaunch,
                onOpenApps = { viewModel.show(Screen.Apps) },
                onOpenSettings = onOpenSettings,
                onOpenWallpaper = { viewModel.show(Screen.Wallpaper) },
                onRequestWatchNext = onRequestWatchNext,
            )

            Screen.Apps -> AppsScreen(
                apps = viewModel.apps,
                favorites = viewModel.favorites,
                hidden = viewModel.hidden,
                onLaunchApp = viewModel::startLaunch,
                onToggleFavorite = viewModel::toggleFavorite,
                onToggleHidden = viewModel::toggleHidden,
                onBack = viewModel::goHome,
            )

            Screen.WatchSources -> WatchSourcesScreen(
                apps = viewModel.visibleApps,
                withItems = viewModel.watchNextPackages,
                selected = viewModel.watchSources,
                onToggle = viewModel::toggleWatchSource,
                onBack = viewModel::goHome,
            )

            Screen.Sizes -> SizeScreen(
                appsSize = viewModel.appsSize,
                watchSize = viewModel.watchSize,
                soundsOn = viewModel.soundsOn,
                onAppsSize = viewModel::setAppsSize,
                onWatchSize = viewModel::setWatchSize,
                onSounds = viewModel::setSounds,
                onBack = viewModel::goHome,
            )

            Screen.Wallpaper -> WallpaperScreen(
                selectedId = viewModel.wallpaperId,
                customWallpaper = viewModel.customWallpaper,
                onSelect = viewModel::selectWallpaper,
                onAddImage = onPickImage,
                onBack = viewModel::goHome,
            )
        }

        viewModel.launching?.let { request ->
            LaunchOverlay(request = request, onExpanded = { onLaunch(request.app.launchIntent) })
        }
    }
}

/** The wallpaper, with a dark gradient on top so text stays readable. */
@Composable
private fun LauncherBackground(
    wallpaperId: String,
    custom: ImageBitmap?,
    extraDim: Boolean,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        // A new wallpaper fades in over the old one instead of switching at once.
        Crossfade(
            targetState = wallpaperId,
            animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            label = "wallpaper",
        ) { id ->
            if (id == Wallpapers.CUSTOM_ID && custom != null) {
                Image(
                    bitmap = custom,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Image(
                    painter = painterResource(Wallpapers.byId(id).res),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x47080A1C), Color(0x14080A1C), Color(0xB8080A1C)),
                    ),
                ),
        )
        // The extra dimming on the other screens fades in and out smoothly.
        val dim by animateFloatAsState(
            targetValue = if (extraDim) 1f else 0f,
            animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
            label = "extraDim",
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.45f * dim)),
        )
    }
}
