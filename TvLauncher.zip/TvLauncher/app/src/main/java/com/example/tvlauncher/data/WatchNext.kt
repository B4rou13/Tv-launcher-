package com.example.tvlauncher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.tvprovider.media.tv.TvContractCompat
import androidx.tvprovider.media.tv.WatchNextProgram

/** One entry of Android TV's "Watch Next" row (what the TV's own home screen calls "Ma sélection"). */
data class WatchNextItem(
    val id: Long,
    val title: String,
    val subtitle: String,
    val description: String,
    val posterUri: Uri?,
    /** 0f..1f, how much has already been watched. */
    val progress: Float,
    val intent: Intent?,
)

object WatchNextRepository {

    const val PERMISSION = "android.permission.READ_TV_LISTINGS"

    /** The list the TV's own home screen uses: the most recently watched first. */
    private const val NEWEST_FIRST = "last_engagement_time_utc_millis DESC"

    fun hasPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, PERMISSION) == PackageManager.PERMISSION_GRANTED

    /**
     * Reads the Watch Next programs. Returns an empty list when the TV does not
     * allow third-party launchers to read them.
     */
    fun load(context: Context): List<WatchNextItem> {
        if (!hasPermission(context)) return emptyList()
        return try {
            read(context, NEWEST_FIRST)
        } catch (e: Exception) {
            // Some TVs do not accept the sort order: read the list without it.
            try {
                read(context, null)
            } catch (e2: Exception) {
                emptyList()
            }
        }
    }

    private fun read(context: Context, sortOrder: String?): List<WatchNextItem> {
        val items = ArrayList<WatchNextItem>()
        context.contentResolver.query(
            TvContractCompat.WatchNextPrograms.CONTENT_URI,
            null, // all columns
            null,
            null,
            sortOrder,
        )?.use { cursor ->
            while (cursor.moveToNext() && items.size < 20) {
                val program = WatchNextProgram.fromCursor(cursor)
                val title = program.title ?: continue

                val duration = program.durationMillis
                val position = program.lastPlaybackPositionMillis
                val progress = if (duration > 0) {
                    (position.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
                } else {
                    0f
                }

                val minutes = if (duration > 0) "${duration / 60_000} min" else null
                val season = program.seasonDisplayNumber
                    ?.takeIf { it.isNotBlank() }?.let { "Season $it" }
                val episode = program.episodeDisplayNumber
                    ?.takeIf { it.isNotBlank() }?.let { "Episode $it" }
                val subtitle = listOfNotNull(season, episode, minutes).joinToString(" · ")

                val intent = try {
                    program.intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                } catch (e: Exception) {
                    null
                }

                items += WatchNextItem(
                    id = program.id,
                    title = title,
                    subtitle = subtitle,
                    description = program.description ?: "",
                    posterUri = program.posterArtUri,
                    progress = progress,
                    intent = intent,
                )
            }
        }
        return items
    }
}
