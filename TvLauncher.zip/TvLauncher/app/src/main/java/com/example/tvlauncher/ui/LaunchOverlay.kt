package com.example.tvlauncher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.example.tvlauncher.LaunchRequest
import kotlin.math.roundToInt

private const val EXPAND_MILLIS = 440

/** A fast start that settles gently, so the tile "springs" open without any bounce. */
private val OpenEasing = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)

/** Eases a value that runs from 0 to 1 so it starts and ends softly. */
private fun smooth(x: Float): Float {
    val t = x.coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
}

/**
 * The "open app" animation. The home screen softly dims, the app's tile grows from where it
 * sits and its corners straighten. Halfway through, the wide banner melts into the app's own
 * colour and its icon takes over in the middle, like a clean splash screen. When the tile
 * fills the screen, [onExpanded] starts the app. The splash stays until the app is up, so
 * there is no flash of the home screen in between.
 */
@Composable
fun LaunchOverlay(request: LaunchRequest, onExpanded: () -> Unit) {
    val progress = remember(request) { Animatable(0f) }
    LaunchedEffect(request) {
        progress.animateTo(1f, tween(durationMillis = EXPAND_MILLIS, easing = OpenEasing))
        onExpanded()
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val fullWidth = constraints.maxWidth.toFloat()
        val fullHeight = constraints.maxHeight.toFloat()

        // If the tile's position is not known, grow from the middle of the screen.
        val start = if (request.bounds.width > 1f && request.bounds.height > 1f) {
            request.bounds
        } else {
            Rect(fullWidth / 2f - 88f, fullHeight / 2f - 50f, fullWidth / 2f + 88f, fullHeight / 2f + 50f)
        }

        val p = progress.value.coerceIn(0f, 1f)
        val left = lerp(start.left, 0f, p)
        val top = lerp(start.top, 0f, p)
        val width = lerp(start.width, fullWidth, p)
        val height = lerp(start.height, fullHeight, p)
        val banner = request.app.banner

        // The banner fades out and the icon fades in between 30% and 80% of the way.
        val swap = smooth((p - 0.3f) / 0.5f)

        // Soft dark veil over the home screen, so the growing tile stands out.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f * smooth(p / 0.6f))),
        )

        Box(
            modifier = Modifier
                .offset { IntOffset(left.roundToInt(), top.roundToInt()) }
                .size(
                    width = with(density) { width.toDp() },
                    height = with(density) { height.toDp() },
                )
                .clip(RoundedCornerShape((14f * (1f - p)).dp))
                .background(appBackground(request.app)),
            contentAlignment = Alignment.Center,
        ) {
            if (banner != null) {
                Image(
                    bitmap = banner,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(1f - swap),
                )
            }
            // The icon grows a little less than the tile, so it ends up small and centred.
            Image(
                bitmap = request.app.icon,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxHeight(lerp(0.6f, 0.3f, p))
                    .aspectRatio(1f)
                    .alpha(if (banner != null) swap else 1f),
            )
        }
    }
}
