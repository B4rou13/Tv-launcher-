package com.example.tvlauncher

import android.content.Context
import android.util.Log

/** Saves the error of a crash so the next start can show it on screen. */
object CrashLog {
    private const val PREFS = "crashlog"
    private const val KEY = "last"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val text = Log.getStackTraceString(error).take(3500)
                app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(KEY, text).commit()
            } catch (e: Throwable) {
                // Nothing more can be done here.
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun read(context: Context): String? = try {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
    } catch (e: Throwable) {
        null
    }

    fun clear(context: Context) {
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).commit()
        } catch (e: Throwable) {
            // Ignore.
        }
    }
}
