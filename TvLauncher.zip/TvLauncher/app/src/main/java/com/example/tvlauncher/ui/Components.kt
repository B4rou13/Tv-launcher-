package com.example.tvlauncher.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.tvlauncher.Sounds
import com.example.tvlauncher.data.AppEntry

internal val FocusColor = Color.White
internal val SubtleText = Color(0xFFD7DEF0)

/** The springy "pop" used for every zoom-on-focus effect, so they all feel the same. */
internal fun <T> zoomSpring() = spring<T>(
    dampingRatio = 0.62f,
    stiffness = Spring.StiffnessMediumLow,
)

internal fun Modifier.optionalFocusRequester(requester: FocusRequester?): Modifier =
    if (requester != null) this.focusRequester(requester) else this

/** Width of a tile on the home screen. The height follows the 16:9 shape. */
internal val TileWidth = 176.dp

/**
 * A wide 16:9 tile with its name underneath. When selected it zooms in, gets a white
 * border, and the name fades in. [onClick] receives the tile's position on screen, which
 * the open-app animation grows from. [badge] is only used while choosing home apps:
 * true = picked (green check), false = not picked (empty ring), null = no badge.
 */
@Composable
fun Tile(
    label: String,
    onClick: (Rect) -> Unit,
    modifier: Modifier = Modifier.width(TileWidth),
    focusRequester: FocusRequester? = null,
    badge: Boolean? = null,
    background: Brush,
    content: @Composable BoxScope.() -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.1f else 1f,
        animationSpec = zoomSpring(),
        label = "tileScale",
    )
    val shape = RoundedCornerShape(14.dp)

    Column(
        modifier = modifier.zIndex(if (focused) 1f else 0f),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .optionalFocusRequester(focusRequester)
                    .onFocusChanged {
                        if (it.isFocused && !focused) Sounds.tick()
                        focused = it.isFocused
                    }
                    .onGloballyPositioned { bounds = it.boundsInRoot() }
                    .clip(shape)
                    .background(background)
                    .border(if (focused) 3.dp else 0.dp, FocusColor, shape)
                    .clickable {
                        Sounds.select()
                        onClick(bounds)
                    },
                contentAlignment = Alignment.Center,
                content = content,
            )
            if (badge != null) {
                SelectBadge(
                    selected = badge,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 6.dp, y = (-6).dp),
                )
            }
        }
        Text(
            text = label,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(top = 12.dp)
                .alpha(if (focused) 1f else 0f),
        )
    }
}

@Composable
private fun SelectBadge(selected: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(if (selected) Color(0xFF2ECC71) else Color(0x99000000))
            .border(2.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Picked",
                tint = Color.White,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/** The colours behind an app's picture. */
internal fun appBackground(app: AppEntry): Brush =
    Brush.linearGradient(listOf(app.tint, lerp(app.tint, Color.Black, 0.45f)))

/**
 * An installed app. Apps with a TV banner fill the whole tile with it; the others show
 * their icon, centred on a dark tile in the icon's own colour.
 */
@Composable
fun AppTile(
    app: AppEntry,
    onClick: (Rect) -> Unit,
    modifier: Modifier = Modifier.width(TileWidth),
    focusRequester: FocusRequester? = null,
    badge: Boolean? = null,
) {
    val banner = app.banner
    Tile(
        label = app.label,
        onClick = onClick,
        modifier = modifier,
        focusRequester = focusRequester,
        badge = badge,
        background = appBackground(app),
    ) {
        if (banner != null) {
            Image(
                bitmap = banner,
                contentDescription = app.label,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Image(
                bitmap = app.icon,
                contentDescription = app.label,
                modifier = Modifier
                    .fillMaxHeight(0.6f)
                    .aspectRatio(1f),
            )
        }
    }
}

/** A tile with one of the launcher's own icons, such as "All apps". */
@Composable
fun ActionTile(
    iconRes: Int,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.width(TileWidth),
    focusRequester: FocusRequester? = null,
) {
    Tile(
        label = label,
        onClick = { onClick() },
        modifier = modifier,
        focusRequester = focusRequester,
        background = Brush.linearGradient(listOf(Color(0x66FFFFFF), Color(0x33FFFFFF))),
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = label,
            tint = Color.White,
            modifier = Modifier.size(44.dp),
        )
    }
}

/** Small icon + title shown above each row. */
@Composable
fun SectionLabel(iconRes: Int, text: String, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp),
        )
        Text(
            text = text,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

/** Round button with a label under it, used in the bottom bar. Zooms when selected. */
@Composable
fun BottomBarButton(iconRes: Int, label: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.3f else 1f,
        animationSpec = zoomSpring(),
        label = "barScale",
    )
    Column(
        modifier = Modifier.width(88.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .onFocusChanged { focused = it.isFocused }
                .clip(CircleShape)
                .background(if (focused) Color.White else Color(0x59000000))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(iconRes),
                contentDescription = label,
                tint = if (focused) Color(0xFF0B0E1B) else Color.White,
                modifier = Modifier.size(26.dp),
            )
        }
        Text(
            text = label,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 12.dp),
        )
    }
}

/** A rounded button with an icon and a label (for example "Background"). Zooms when selected. */
@Composable
fun PillButton(
    iconRes: Int,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.15f else 1f,
        animationSpec = zoomSpring(),
        label = "pillScale",
    )
    val shape = RoundedCornerShape(50)
    Row(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .onFocusChanged {
                if (it.isFocused && !focused) Sounds.tick()
                focused = it.isFocused
            }
            .clip(shape)
            .background(
                when {
                    focused -> Color.White
                    selected -> Color(0x66FFFFFF)
                    else -> Color(0x8C0A0C1C)
                },
            )
            .border(if (selected && !focused) 2.dp else 1.dp, if (selected) Color.White else Color(0x66FFFFFF), shape)
            .clickable {
                Sounds.select()
                onClick()
            }
            .padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = null,
            tint = if (focused) Color(0xFF0B0E1B) else Color.White,
            modifier = Modifier.size(20.dp),
        )
        Text(
            text = label,
            color = if (focused) Color(0xFF0B0E1B) else Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
