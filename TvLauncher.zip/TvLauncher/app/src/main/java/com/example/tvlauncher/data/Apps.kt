package com.example.tvlauncher.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.roundToInt

/** One launchable app, with its icon (and TV banner, when it has one) already rendered. */
data class AppEntry(
    val label: String,
    val packageName: String,
    val launchIntent: Intent,
    val icon: ImageBitmap,
    /** The wide 16:9 picture Android TV apps provide, or null for apps without one. */
    val banner: ImageBitmap?,
    /** A dark colour taken from the icon, used behind it so the tile looks clean. */
    val tint: Color,
)

object AppRepository {

    private const val ICON_SIZE_PX = 192
    private const val BANNER_WIDTH_PX = 384

    /**
     * Lists every app that can be started from a TV: apps that declare the Leanback
     * launcher category and also regular launcher apps (many sideloaded apps only
     * have the second one).
     */
    fun load(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val result = ArrayList<AppEntry>()

        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (info in pm.queryIntentActivities(query, 0)) {
                val pkg = info.activityInfo.packageName
                if (pkg == context.packageName || !seen.add(pkg)) continue

                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: continue
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                val iconBitmap: Bitmap = try {
                    info.loadIcon(pm).toBitmap(ICON_SIZE_PX, ICON_SIZE_PX)
                } catch (e: Exception) {
                    continue
                }

                val banner: ImageBitmap? = try {
                    val drawable = info.activityInfo.loadBanner(pm)
                        ?: info.activityInfo.applicationInfo.loadBanner(pm)
                    drawable?.let(::renderBanner)
                } catch (e: Exception) {
                    null
                }

                result += AppEntry(
                    label = info.loadLabel(pm).toString(),
                    packageName = pkg,
                    launchIntent = launch,
                    icon = iconBitmap.asImageBitmap(),
                    banner = banner,
                    tint = tintFor(iconBitmap),
                )
            }
        }
        return result.sortedBy { it.label.lowercase() }
    }

    /** Draws the banner at a fixed width, keeping its own proportions. */
    private fun renderBanner(drawable: Drawable): ImageBitmap {
        val width = drawable.intrinsicWidth.takeIf { it > 0 } ?: 320
        val height = drawable.intrinsicHeight.takeIf { it > 0 } ?: 180
        val targetHeight = (height * BANNER_WIDTH_PX.toFloat() / width).roundToInt().coerceAtLeast(1)
        return drawable.toBitmap(BANNER_WIDTH_PX, targetHeight).asImageBitmap()
    }

    /** The icon's average colour, darkened, so the tile behind the icon matches it. */
    private fun tintFor(icon: Bitmap): Color {
        return try {
            val pixel = Bitmap.createScaledBitmap(icon, 1, 1, true).getPixel(0, 0)
            lerp(Color(pixel).copy(alpha = 1f), Color.Black, 0.5f)
        } catch (e: Exception) {
            Color(0xFF222633)
        }
    }
}
