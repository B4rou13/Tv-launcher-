package com.example.tvlauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tvlauncher.R
import com.example.tvlauncher.data.AppEntry
import kotlinx.coroutines.delay

/**
 * Pick the apps whose films and series appear in Continue watching. With no tick at all,
 * every app is shown. Apps that have something in the list right now come first.
 */
@Composable
fun WatchSourcesScreen(
    apps: List<AppEntry>,
    withItems: Set<String>,
    selected: List<String>,
    onToggle: (String) -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)

    val sorted = remember(apps, withItems) { apps.sortedByDescending { it.packageName in withItems } }
    val firstApp = remember { FocusRequester() }
    LaunchedEffect(sorted.isNotEmpty()) {
        if (sorted.isNotEmpty()) {
            delay(150)
            runCatching { firstApp.requestFocus() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 24.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 56.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Apps for Continue watching",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.weight(1f))
            PillButton(iconRes = R.drawable.ic_apps, label = "Done", onClick = onBack)
        }
        Text(
            text = "Select an app to show its films and series in the row. Apps with a tick are shown. " +
                "With no tick, every app is shown. Apps with something to continue come first.",
            color = SubtleText,
            fontSize = 13.sp,
            modifier = Modifier.padding(start = 56.dp, end = 56.dp, top = 4.dp),
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            contentPadding = PaddingValues(horizontal = 56.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            itemsIndexed(sorted, key = { _, app -> app.packageName }) { index, app ->
                AppTile(
                    app = app,
                    onClick = { onToggle(app.packageName) },
                    modifier = Modifier.fillMaxWidth(),
                    focusRequester = if (index == 0) firstApp else null,
                    badge = app.packageName in selected,
                )
            }
        }
    }
}
