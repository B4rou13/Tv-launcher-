package com.example.tvlauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tvlauncher.R
import kotlinx.coroutines.delay

/** Tile widths (in dp) for Small, Medium and Large. Medium is the size used before. */
internal val AppsWidths = listOf(140f, 176f, 196f)
internal val WatchWidths = listOf(180f, 220f, 236f)

private val SizeNames = listOf("Small", "Medium", "Large")

/** Choose how big the home apps and the Continue watching cards are, and turn sounds on or off. */
@Composable
fun SizeScreen(
    appsSize: Int,
    watchSize: Int,
    soundsOn: Boolean,
    onAppsSize: (Int) -> Unit,
    onWatchSize: (Int) -> Unit,
    onSounds: (Boolean) -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)

    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { first.requestFocus() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 56.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Size & sound",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.weight(1f))
            PillButton(iconRes = R.drawable.ic_apps, label = "Done", onClick = onBack)
        }
        Text(
            text = "Every app on the home screen has the same size. The same goes for the Continue watching cards.",
            color = SubtleText,
            fontSize = 13.sp,
        )
        Spacer(Modifier.height(18.dp))

        OptionRow(title = "Apps size") {
            SizeNames.forEachIndexed { index, name ->
                PillButton(
                    iconRes = R.drawable.ic_apps,
                    label = name,
                    selected = index == appsSize,
                    onClick = { onAppsSize(index) },
                    modifier = if (index == appsSize) Modifier.focusRequester(first) else Modifier,
                )
            }
        }
        OptionRow(title = "Continue watching size") {
            SizeNames.forEachIndexed { index, name ->
                PillButton(
                    iconRes = R.drawable.ic_play,
                    label = name,
                    selected = index == watchSize,
                    onClick = { onWatchSize(index) },
                )
            }
        }
        OptionRow(title = "Sounds") {
            PillButton(
                iconRes = R.drawable.ic_play,
                label = "On",
                selected = soundsOn,
                onClick = { onSounds(true) },
            )
            PillButton(
                iconRes = R.drawable.ic_hide,
                label = "Off",
                selected = !soundsOn,
                onClick = { onSounds(false) },
            )
        }
    }
}

@Composable
private fun OptionRow(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.padding(top = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = title,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { content() }
    }
}
